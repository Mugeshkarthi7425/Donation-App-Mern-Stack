import React from 'react'

const Admin = () => {
  return (
    <div>Admin Page</div>
  )
}

export default Admin