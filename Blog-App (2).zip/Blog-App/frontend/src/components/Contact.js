import React from 'react'

const Contact = () => {
  return (
    <center><div><h1>Welcome to Contact Page</h1></div></center>
  )
}

export default Contact