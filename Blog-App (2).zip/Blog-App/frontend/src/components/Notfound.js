import React from 'react'

const Notfound = () => {
  return (
    <div>Page Not found</div>
  )
}

export default Notfound